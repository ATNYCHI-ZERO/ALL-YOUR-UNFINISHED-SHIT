# Crypto Tests
Ensure constant-time discipline; add ctgrind/valgrind or dudect harness later.
