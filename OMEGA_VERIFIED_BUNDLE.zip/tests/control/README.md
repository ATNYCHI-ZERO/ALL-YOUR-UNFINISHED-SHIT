# Control Tests
Define PID and LQR targets; include WCET bounds and stability margins.
