# FRA Stub
MMU/timer/console contracts with minimal TCB.
