# VM Stub
Cooperative scheduler; bytecode interpreter; FRA interfaces.
