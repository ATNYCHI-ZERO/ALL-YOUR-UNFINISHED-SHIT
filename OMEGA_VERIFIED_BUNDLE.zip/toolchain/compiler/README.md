# Compiler Stub
FrontEnd→IR1→IR2→RV32IM pipeline; hooks for proof artifacts.
