# Coq Workbench (v0.1)
- Build: `make`
- Start: `coqide` or `ProofGeneral` on files in `src/`.
