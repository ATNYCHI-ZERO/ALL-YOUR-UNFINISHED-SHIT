# Scripts
Add CI scripts for Coq/Isabelle and tests.
