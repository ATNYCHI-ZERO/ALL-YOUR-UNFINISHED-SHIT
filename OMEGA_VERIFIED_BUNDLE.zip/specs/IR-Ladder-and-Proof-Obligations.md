# IR Ladder & Proof Obligations (v0.1)

## Passes
1. **FE→IR1 (StructNorm):** Desugar `if/while` into basic blocks with explicit terminators.
2. **IR1→IR2 (SSAForm):** Convert to SSA, insert φ-nodes.
3. **IR2→RV32IM (Sel):** Instruction selection + register allocation (linear scan).

## Proof Obligations
- **O1 (SemPres-FE→IR1)**: Simulation diagram between small-step FE and IR1.
- **O2 (SemPres-IR1→IR2)**: SSA correctness (dominance, φ-placement), value equivalence.
- **O3 (SemPres-IR2→RV32IM)**: Target code preserves observable behavior (trace equivalence); integer overflow semantics aligned.
- **O4 (Alloc-Correctness)**: Allocated registers respect liveness; no clobbering.
- **O5 (ABI/Calling Conv)**: (deferred to v0.2)

Artifacts: Coq files `SemPres_FE_IR1.v`, `SemPres_IR1_IR2.v`, `SemPres_IR2_RV32.v`.
