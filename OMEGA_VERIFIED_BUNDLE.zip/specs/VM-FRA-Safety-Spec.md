# VM / FRA Safety Spec (v0.1)

## VM
- Single address space; flat heap; bounds-checked loads/stores.
- Scheduler: cooperative (yield points), max quantum bound Q (configurable).
- Invariants: memory safety, no-use-after-free (trivial in v0.1 via no free).

## FRA (Formal Runtime Architecture)
- Contracts: MMU (abstract), Timer, Console I/O.
- TCB minimization: isolate I/O behind verified stubs.
- Properties (to prove): type soundness of bytecode exec; scheduler liveness (no starvation); bound on run-to-yield ≤ Q.

## Interfaces
- `vm_exec(bytecode, heap0) -> (heap1, exitcode)`
- `fra_putc`, `fra_getc`, `fra_time` with total specs.
