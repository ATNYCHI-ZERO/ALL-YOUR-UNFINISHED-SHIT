# Silicon Modeling Scope (RV32IM v0.1)

## Micro-arch Model
- In-order 5-stage pipeline; no speculation.
- Caches disabled (v0.1) to simplify timing model.
- Instruction timings: each op has fixed cost; branches include penalty.

## WCET Envelope
- Path-sensitive bound with loop invariants (user-provided).
- Scheduler quantum Q chosen to dominate worst basic block.

## Side-Channel Model
- Timing only (no cache/micro-arch channels in v0.1).
- Constant-time discipline for crypto kernels: no secret-dependent control flow or addresses.
