# K-While v0.1 — Language Semantics

## 1. Syntax (BNF)
```
t ∈ types ::= int | bool
op ∈ binop ::= + | - | * | / | % | < | <= | == | != | && ||

e ∈ expr ::= n | true | false | x | e op e
c ∈ cmd  ::= skip | x := e | c ; c | if e then c else c | while e do c
p ∈ prog ::= {globals; main: c}
```

## 2. Typing
Judgments: Γ ⊢ e : t ; Γ ⊢ c ✓

- Arithmetic ops require `int`; logical ops require `bool`. No implicit casts.
- All variables declared in `globals` with type; no uninitialized reads.

## 3. Operational Semantics
Small-step relation `(σ, c) → (σ', c')` where σ : Var → Val.
Define rules for assignment, sequencing, conditional, loop (with standard unrolling).

## 4. Safety Theorems (Goals)
- **Progress**: Well-typed `(σ, c)` is either `skip` or can take a step.
- **Preservation**: If `(σ, c) → (σ', c')` and `Γ ⊢ c ✓`, then `Γ ⊢ c' ✓`.

## 5. Memory Model
- Flat memory; integers are mathematical ints; later mapped to 32-bit with wrap semantics in the backend proof.

## 6. Extensions Planned
- Procedures, arrays, I/O effects, concurrency (v0.2+).
