# Ω-Verified Toolchain Seed (v0.1)
**Generated:** 2025-11-25 22:08:54 (local runtime)

This bundle provides:
- **Specs**: Language semantics, IR ladder + proof obligations, VM/FRA safety, and silicon modeling scope.
- **Proof Workbenches**: Coq and Isabelle skeletons for semantic preservation, non-interference (crypto), and interval analysis (PDE).
- **Conformance Tests**: Minimal control/crypto/PDE cases with checklists.
- **Toolchain Stubs**: Compiler/VM/FRA placeholders with interfaces.

## Defaults (editable)
- **Source language subset:** `K-While v0.1` (typed, total expressions, structured control; no UB; single-threaded for v0.1).
- **Target ISA:** RISC‑V RV32IM (proof profile); optional AArch64 profile to be added in v0.2.
- **Proof goals (phase-1):**
  1. Type soundness (progress/preservation) for K-While.
  2. Semantic preservation for FrontEnd → IR1 → IR2 → RV32IM.
  3. VM safety (memory, scheduler bounds; single-task runtime in v0.1).
  4. Crypto non-interference (constant-time) lemma for reference SHA/AES kernels.
  5. PDE interval-error bound for a Poisson solver test case.

## Layout
- `specs/` — Markdown specs.
- `proofs/coq/`, `proofs/isabelle/` — Proof skeletons.
- `tests/` — Control/Crypto/PDE minimal cases.
- `toolchain/` — Compiler/VM/FRA placeholders.
- `scripts/` — Make targets to build proofs and run tests.

## Getting Started
```bash
# Coq (example)
make -C proofs/coq

# Isabelle
make -C proofs/isabelle

# Run starter tests (placeholders)
python3 tests/run_all.py
```

---
